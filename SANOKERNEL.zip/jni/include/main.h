//
// Created by Ssage on 2022/3/18.
//
#ifndef SSAGEPARUDERS_NATIVE_SURFACE_H
#define SSAGEPARUDERS_NATIVE_SURFACE_H
// User libs
#include <draw.h>
#include <TouchHelper.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <linux/input.h>
#include <dirent.h>
#include <timer.h>
#include <sys/mman.h>
#include <imgui_internal.h>
#include <dirent.h>
// Func
void Rendering(bool *flag);
#endif //SSAGEPARUDERS_NATIVE_SURFACE_H
