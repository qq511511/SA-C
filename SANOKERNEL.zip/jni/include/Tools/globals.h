#ifndef GLOBALS_H
#define GLOBALS_H

#include <string>

using namespace std;

extern int 服务器;
extern bool IsBall;
extern bool IsLoGin;
extern bool IsDown;
extern bool IsWin;
extern bool BallSwitch;
extern bool MemuSwitch;
extern int 进程pid;
extern int 开火;
//用户定义按钮区
extern long int 模块地址;
extern long int 数组;
extern long int 矩阵;
extern long int 自身;
extern int 数量;
extern int 后台;
extern bool 初始化;
extern int 循环力度;


#endif 
