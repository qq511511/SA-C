#include "globals.h"
#include <string>

using namespace std;

int 服务器 = 0; // 在某个源文件中进行全局变量的定义
bool IsBall = true;
bool IsLoGin = true;
bool IsDown = false;
bool IsWin = true;
bool BallSwitch = false;
bool MemuSwitch = true;
long int 模块地址 = 0;
long int 数组 = 0;
long int 矩阵 = 0;
long int 自身;
int 数量 = 0;
int 进程pid = 0;
int 开火 = 0;
int 后台 = 0;
bool 初始化 = false;
int 循环力度 = 1;




