#ifndef SHOU_H
#define SHOU_H
#include <sched.h>
#include <unistd.h>
#include <time.h>
#include <thread>
#include <random>
#include <linux/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <fstream>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <unordered_map>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <thread>
#include <array>
#include <android/native_window_jni.h>
#include "imgui.h"
#include "imgui_image.h"
#include "imgui_internal.h"
#include "纹理.h"
#include "tupian.h"

ImTextureID FloatBallwd;//悬浮球
ImVec2 ImagePos = {0, 0};
ImGuiWindow *Window = nullptr;

void 帅哥(){
	FloatBallwd = ImAgeHeadFile(png, sizeof(png));
}

//图标
void DrawLogo(ImTextureID ID,ImVec2 center, float size)
{
	ImGui::SetCursorPos({180, 180});
	ImDrawList *draw_list = ImGui::GetWindowDrawList();
	draw_list->AddImage(ID,{center.x - size / 1, center.y - size / 1},{center.x + size / 1, center.y + size / 1});
}






void 温迪(){
		ImGuiStyle * style = &ImGui::GetStyle();
		// 文本颜色保持亮白
// 优化后的灰黑色主题（保留原图布局特征）
style->Colors[ImGuiCol_Text]               = ImColor(230, 230, 230, 255);  // 浅灰文字
style->Colors[ImGuiCol_TextDisabled]       = ImColor(150, 150, 150, 255);
style->Colors[ImGuiCol_WindowBg]            = ImColor(28, 28, 33, 220);    // 深灰半透明背景
style->Colors[ImGuiCol_ChildBg]            = ImColor(40, 40, 45, 200);
style->Colors[ImGuiCol_PopupBg]            = ImColor(35, 35, 40, 240);
style->Colors[ImGuiCol_Border]             = ImColor(70, 70, 75, 255);    // 中灰边框
style->Colors[ImGuiCol_BorderShadow]        = ImColor(20, 20, 25, 100);
style->Colors[ImGuiCol_FrameBg]            = ImColor(50, 50, 55, 200);    // 控件背景
style->Colors[ImGuiCol_FrameBgHovered]      = ImColor(65, 65, 70, 220);
style->Colors[ImGuiCol_FrameBgActive]       = ImColor(75, 75, 80, 220);

// 进度条配色（保持原图绿色系）
style->Colors[ImGuiCol_PlotHistogram]       = ImColor(100, 200, 80, 255);   // 主要进度条
style->Colors[ImGuiCol_PlotHistogramHovered]= ImColor(120, 220, 100, 255);

// 交互元素配色
style->Colors[ImGuiCol_Button]             = ImColor(60, 60, 65, 220);     // 灰黑按钮
style->Colors[ImGuiCol_ButtonHovered]       = ImColor(80, 80, 85, 240);
style->Colors[ImGuiCol_ButtonActive]        = ImColor(100, 100, 105, 255);
style->Colors[ImGuiCol_ScrollbarGrab]       = ImColor(90, 90, 95, 255);    // 滚动条抓取
style->Colors[ImGuiCol_ScrollbarGrabHovered]= ImColor(110, 110, 115, 255);
style->Colors[ImGuiCol_Header]              = ImColor(65, 65, 70, 180);    // 分组标题

// 保留原有布局参数
style->WindowPadding = ImVec2(20, 20);
style->WindowRounding = 50.0f;               // 大圆角窗口
style->FramePadding = ImVec2(5, 5);           // 控件内边距
style->FrameBorderSize = 0.5f;
style->WindowBorderSize = 18.0f;              // 显著边框厚度
style->GrabRounding = 15.0f;
style->GrabMinSize = 35.0f;
style->FrameRounding = 15.0f;
style->ScrollbarSize = 35.0f;                 // 宽滚动条
style->ScrollbarRounding = 15.0f;             // 滚动条圆角
style->WindowTitleAlign = ImVec2(0.5, 0.5);   // 标题居中

// 透明度设置
ImGui::SetNextWindowBgAlpha(0.95f);          // 微透明背景
       
}

#endif

